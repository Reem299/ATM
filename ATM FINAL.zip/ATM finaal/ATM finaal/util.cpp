#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"

// Helper function to find modular inverse
int modInverse(int a, int m) {
    a = a % m;
    for (int x = 1; x < m; x++) {
        if ((a * x) % m == 1)
            return x;
    }
    return -1;
}

// Function to encrypt a string using Hill Cipher (2x2)
void encryptHillCipher(const char* plaintext, char* ciphertext, int key[2][2]) {
    int i = 0, length = strlen(plaintext);
    // Ensure the length is even by padding with 'X' if needed
    if (length % 2 != 0) {
        ciphertext[length] = 'X';
        ciphertext[length + 1] = '\0';
        length++;
    }

    while (i < length) {
        int p1 = plaintext[i] - 'A';     // Map A-Z to 0-25
        int p2 = plaintext[i + 1] - 'A';

        int c1 = (key[0][0] * p1 + key[0][1] * p2) % 26;
        int c2 = (key[1][0] * p1 + key[1][1] * p2) % 26;

        ciphertext[i] = c1 + 'A';
        ciphertext[i + 1] = c2 + 'A';

        i += 2;
    }
    ciphertext[length] = '\0'; // Null terminate the string
}

// Function to decrypt a string using Hill Cipher (2x2)
void decryptHillCipher(const char* ciphertext, char* plaintext, int key[2][2]) {
    int det = key[0][0] * key[1][1] - key[0][1] * key[1][0]; // Determinant of the key matrix
    det = (det % 26 + 26) % 26; // Ensure positive determinant modulo 26
    int detInv = modInverse(det, 26); // Modular inverse of the determinant

    if (detInv == -1) {
        printf("ERROR: Key matrix is not invertible!\n");
        return;
    }

    // Compute the inverse key matrix modulo 26
    int invKey[2][2];
    invKey[0][0] = (key[1][1] * detInv) % 26;
    invKey[1][1] = (key[0][0] * detInv) % 26;
    invKey[0][1] = (-key[0][1] * detInv + 26) % 26;
    invKey[1][0] = (-key[1][0] * detInv + 26) % 26;

    int i = 0, length = strlen(ciphertext);
    while (i < length) {
        int c1 = ciphertext[i] - 'A';
        int c2 = ciphertext[i + 1] - 'A';

        int p1 = (invKey[0][0] * c1 + invKey[0][1] * c2) % 26;
        int p2 = (invKey[1][0] * c1 + invKey[1][1] * c2) % 26;

        plaintext[i] = p1 + 'A';
        plaintext[i + 1] = p2 + 'A';

        i += 2;
    }
    plaintext[length] = '\0'; // Null terminate the string
}
