#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "transactions.h"

// function to record the transaction in CSV file to show it in history if needed
void Monitor_Transactions(int User_ID, char transaction_type, float amount)
{
	FILE* file = fopen("transactions.csv", "a");
	if (!file)
	{
		perror("Error Opening Transactions File");
		return;
	}
	static int NO_Of_Transaction = 1;
	fprintf(file, "%d,%d,%c,%.2f\n", NO_Of_Transaction++, User_ID, transaction_type, amount);
	fclose(file);
}
//function to check and print the user's Account balance
void Balance_Inquiry(User* user)
{
	printf("Your Current balance is: %.2f\n", user->Account_balance);
}
// function to deposit funds then update the user's account balance
void Deposit_Funds(User* user, float Deposit_Amount)
{
	if (Deposit_Amount > 0)
	{
		user->Account_balance += Deposit_Amount;
		printf("Deposit is Done successfully and Your Balance is : %.2f\n", user->Account_balance);
		Monitor_Transactions(user->User_ID, 'D', Deposit_Amount); //update it to the csv to show it in transaction history if needed
	}
	else
	{
		printf("Invalid Amount\n");
	}
}

//function to withdraw funds
void Withdraw_Funds(User* user, float Withdraw_Amount)
{
	if (Withdraw_Amount > 0 && Withdraw_Amount <= user->Account_balance)
	{
		user->Account_balance -= Withdraw_Amount; //withdraw from the user account 
		printf("withdraw is successful and your Account balance is: %.2f\n", user->Account_balance);
		Monitor_Transactions(user->User_ID, 'W', Withdraw_Amount); //then update it to the csv to show it in transaction history if needed
	}
	else if (Withdraw_Amount < 0)
	{
		printf("Invalid amount \n"); // if it is negative input give error message
	}
	else if (Withdraw_Amount > user->Account_balance)
	{
		printf("Non-Available Balance\n"); //if it greater than the available balance give an error message
	}
}
// to show all trasaction history for the user
void Transaction_History(int User_ID)
{
	FILE* file = fopen("transactions.csv", "r");
	if (!file)
	{
		perror("ERROR openning transactions file");
		return;
	}
	char line[200];
	float amount;
    int NO_Of_Transaction;
	int tid_user_id;
	char transaction_type;
	printf("Your transaction history is\n");
	printf("ID\tType\tAmount\n");

	fgets(line, sizeof(line), file);

	while (fgets(line, sizeof(line), file))
	{
		if (sscanf(line, "%d,%d,%c,%f", &NO_Of_Transaction, &tid_user_id, &transaction_type, &amount) == 4)
		{
			if (tid_user_id == User_ID)
			{
				printf("%d\t%c\t%.2f\n", NO_Of_Transaction, transaction_type, amount);
			}
		}
	}
	fclose(file);
}
// to free users in the linked list
void Free_Spots(struct User* head)
{
	struct User* Temp;
	while (head != NULL)
	{
		Temp = head;
		head = head->next;
		free(Temp);
	}
}