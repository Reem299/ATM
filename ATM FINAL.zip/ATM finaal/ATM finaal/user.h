#pragma once
#ifndef USER_H
#define USER_H

typedef struct User
{
	int User_ID;
	char username[30];
	char password[5];
	float Account_balance;
	struct User* next;
}User;

//functions
struct User* RegisterUser(int id, const char* username, const char* password, float balance);
struct User* LoadUserData(const char* File_name);
struct User* User_Authentication(struct User* head, const char* username, const char* password);


#endif